import Http from './Http'
const App = {
    Http: Object.assign(Http, Http),
}

export default App