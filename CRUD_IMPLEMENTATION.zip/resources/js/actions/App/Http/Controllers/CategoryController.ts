import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\CategoryController::indexCategories
 * @see app/Http/Controllers/CategoryController.php:15
 * @route '/admin/categories'
 */
export const indexCategories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCategories.url(options),
    method: 'get',
})

indexCategories.definition = {
    methods: ["get","head"],
    url: '/admin/categories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::indexCategories
 * @see app/Http/Controllers/CategoryController.php:15
 * @route '/admin/categories'
 */
indexCategories.url = (options?: RouteQueryOptions) => {
    return indexCategories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::indexCategories
 * @see app/Http/Controllers/CategoryController.php:15
 * @route '/admin/categories'
 */
indexCategories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexCategories.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::indexCategories
 * @see app/Http/Controllers/CategoryController.php:15
 * @route '/admin/categories'
 */
indexCategories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexCategories.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::indexCategories
 * @see app/Http/Controllers/CategoryController.php:15
 * @route '/admin/categories'
 */
    const indexCategoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: indexCategories.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::indexCategories
 * @see app/Http/Controllers/CategoryController.php:15
 * @route '/admin/categories'
 */
        indexCategoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexCategories.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::indexCategories
 * @see app/Http/Controllers/CategoryController.php:15
 * @route '/admin/categories'
 */
        indexCategoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexCategories.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    indexCategories.form = indexCategoriesForm
/**
* @see \App\Http\Controllers\CategoryController::createCategory
 * @see app/Http/Controllers/CategoryController.php:24
 * @route '/admin/categories/create'
 */
export const createCategory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCategory.url(options),
    method: 'get',
})

createCategory.definition = {
    methods: ["get","head"],
    url: '/admin/categories/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::createCategory
 * @see app/Http/Controllers/CategoryController.php:24
 * @route '/admin/categories/create'
 */
createCategory.url = (options?: RouteQueryOptions) => {
    return createCategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::createCategory
 * @see app/Http/Controllers/CategoryController.php:24
 * @route '/admin/categories/create'
 */
createCategory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createCategory.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::createCategory
 * @see app/Http/Controllers/CategoryController.php:24
 * @route '/admin/categories/create'
 */
createCategory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createCategory.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::createCategory
 * @see app/Http/Controllers/CategoryController.php:24
 * @route '/admin/categories/create'
 */
    const createCategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: createCategory.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::createCategory
 * @see app/Http/Controllers/CategoryController.php:24
 * @route '/admin/categories/create'
 */
        createCategoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createCategory.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::createCategory
 * @see app/Http/Controllers/CategoryController.php:24
 * @route '/admin/categories/create'
 */
        createCategoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createCategory.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    createCategory.form = createCategoryForm
/**
* @see \App\Http\Controllers\CategoryController::storeCategory
 * @see app/Http/Controllers/CategoryController.php:29
 * @route '/admin/categories'
 */
export const storeCategory = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

storeCategory.definition = {
    methods: ["post"],
    url: '/admin/categories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CategoryController::storeCategory
 * @see app/Http/Controllers/CategoryController.php:29
 * @route '/admin/categories'
 */
storeCategory.url = (options?: RouteQueryOptions) => {
    return storeCategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::storeCategory
 * @see app/Http/Controllers/CategoryController.php:29
 * @route '/admin/categories'
 */
storeCategory.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeCategory.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CategoryController::storeCategory
 * @see app/Http/Controllers/CategoryController.php:29
 * @route '/admin/categories'
 */
    const storeCategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeCategory.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::storeCategory
 * @see app/Http/Controllers/CategoryController.php:29
 * @route '/admin/categories'
 */
        storeCategoryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeCategory.url(options),
            method: 'post',
        })
    
    storeCategory.form = storeCategoryForm
/**
* @see \App\Http\Controllers\CategoryController::editCategory
 * @see app/Http/Controllers/CategoryController.php:44
 * @route '/admin/categories/{category}/edit'
 */
export const editCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCategory.url(args, options),
    method: 'get',
})

editCategory.definition = {
    methods: ["get","head"],
    url: '/admin/categories/{category}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::editCategory
 * @see app/Http/Controllers/CategoryController.php:44
 * @route '/admin/categories/{category}/edit'
 */
editCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return editCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::editCategory
 * @see app/Http/Controllers/CategoryController.php:44
 * @route '/admin/categories/{category}/edit'
 */
editCategory.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editCategory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::editCategory
 * @see app/Http/Controllers/CategoryController.php:44
 * @route '/admin/categories/{category}/edit'
 */
editCategory.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editCategory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::editCategory
 * @see app/Http/Controllers/CategoryController.php:44
 * @route '/admin/categories/{category}/edit'
 */
    const editCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: editCategory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::editCategory
 * @see app/Http/Controllers/CategoryController.php:44
 * @route '/admin/categories/{category}/edit'
 */
        editCategoryForm.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editCategory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::editCategory
 * @see app/Http/Controllers/CategoryController.php:44
 * @route '/admin/categories/{category}/edit'
 */
        editCategoryForm.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    editCategory.form = editCategoryForm
/**
* @see \App\Http\Controllers\CategoryController::updateCategory
 * @see app/Http/Controllers/CategoryController.php:51
 * @route '/admin/categories/{category}'
 */
export const updateCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

updateCategory.definition = {
    methods: ["put"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CategoryController::updateCategory
 * @see app/Http/Controllers/CategoryController.php:51
 * @route '/admin/categories/{category}'
 */
updateCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return updateCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::updateCategory
 * @see app/Http/Controllers/CategoryController.php:51
 * @route '/admin/categories/{category}'
 */
updateCategory.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateCategory.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CategoryController::updateCategory
 * @see app/Http/Controllers/CategoryController.php:51
 * @route '/admin/categories/{category}'
 */
    const updateCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateCategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::updateCategory
 * @see app/Http/Controllers/CategoryController.php:51
 * @route '/admin/categories/{category}'
 */
        updateCategoryForm.put = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateCategory.form = updateCategoryForm
/**
* @see \App\Http\Controllers\CategoryController::destroyCategory
 * @see app/Http/Controllers/CategoryController.php:66
 * @route '/admin/categories/{category}'
 */
export const destroyCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

destroyCategory.definition = {
    methods: ["delete"],
    url: '/admin/categories/{category}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CategoryController::destroyCategory
 * @see app/Http/Controllers/CategoryController.php:66
 * @route '/admin/categories/{category}'
 */
destroyCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return destroyCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::destroyCategory
 * @see app/Http/Controllers/CategoryController.php:66
 * @route '/admin/categories/{category}'
 */
destroyCategory.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroyCategory.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CategoryController::destroyCategory
 * @see app/Http/Controllers/CategoryController.php:66
 * @route '/admin/categories/{category}'
 */
    const destroyCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroyCategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::destroyCategory
 * @see app/Http/Controllers/CategoryController.php:66
 * @route '/admin/categories/{category}'
 */
        destroyCategoryForm.delete = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroyCategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroyCategory.form = destroyCategoryForm
/**
* @see \App\Http\Controllers\CategoryController::manageTechnicianCategories
 * @see app/Http/Controllers/CategoryController.php:147
 * @route '/admin/categories/{category}/technicians'
 */
export const manageTechnicianCategories = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: manageTechnicianCategories.url(args, options),
    method: 'get',
})

manageTechnicianCategories.definition = {
    methods: ["get","head"],
    url: '/admin/categories/{category}/technicians',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::manageTechnicianCategories
 * @see app/Http/Controllers/CategoryController.php:147
 * @route '/admin/categories/{category}/technicians'
 */
manageTechnicianCategories.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return manageTechnicianCategories.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::manageTechnicianCategories
 * @see app/Http/Controllers/CategoryController.php:147
 * @route '/admin/categories/{category}/technicians'
 */
manageTechnicianCategories.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: manageTechnicianCategories.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::manageTechnicianCategories
 * @see app/Http/Controllers/CategoryController.php:147
 * @route '/admin/categories/{category}/technicians'
 */
manageTechnicianCategories.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: manageTechnicianCategories.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::manageTechnicianCategories
 * @see app/Http/Controllers/CategoryController.php:147
 * @route '/admin/categories/{category}/technicians'
 */
    const manageTechnicianCategoriesForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: manageTechnicianCategories.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::manageTechnicianCategories
 * @see app/Http/Controllers/CategoryController.php:147
 * @route '/admin/categories/{category}/technicians'
 */
        manageTechnicianCategoriesForm.get = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: manageTechnicianCategories.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::manageTechnicianCategories
 * @see app/Http/Controllers/CategoryController.php:147
 * @route '/admin/categories/{category}/technicians'
 */
        manageTechnicianCategoriesForm.head = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: manageTechnicianCategories.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    manageTechnicianCategories.form = manageTechnicianCategoriesForm
/**
* @see \App\Http\Controllers\CategoryController::assignTechniciansToCategory
 * @see app/Http/Controllers/CategoryController.php:159
 * @route '/admin/categories/{category}/assign-technicians'
 */
export const assignTechniciansToCategory = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignTechniciansToCategory.url(args, options),
    method: 'post',
})

assignTechniciansToCategory.definition = {
    methods: ["post"],
    url: '/admin/categories/{category}/assign-technicians',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CategoryController::assignTechniciansToCategory
 * @see app/Http/Controllers/CategoryController.php:159
 * @route '/admin/categories/{category}/assign-technicians'
 */
assignTechniciansToCategory.url = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { category: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { category: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    category: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        category: typeof args.category === 'object'
                ? args.category.id
                : args.category,
                }

    return assignTechniciansToCategory.definition.url
            .replace('{category}', parsedArgs.category.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::assignTechniciansToCategory
 * @see app/Http/Controllers/CategoryController.php:159
 * @route '/admin/categories/{category}/assign-technicians'
 */
assignTechniciansToCategory.post = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assignTechniciansToCategory.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CategoryController::assignTechniciansToCategory
 * @see app/Http/Controllers/CategoryController.php:159
 * @route '/admin/categories/{category}/assign-technicians'
 */
    const assignTechniciansToCategoryForm = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assignTechniciansToCategory.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::assignTechniciansToCategory
 * @see app/Http/Controllers/CategoryController.php:159
 * @route '/admin/categories/{category}/assign-technicians'
 */
        assignTechniciansToCategoryForm.post = (args: { category: number | { id: number } } | [category: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assignTechniciansToCategory.url(args, options),
            method: 'post',
        })
    
    assignTechniciansToCategory.form = assignTechniciansToCategoryForm
/**
* @see \App\Http\Controllers\CategoryController::indexSubcategories
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
export const indexSubcategories = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexSubcategories.url(options),
    method: 'get',
})

indexSubcategories.definition = {
    methods: ["get","head"],
    url: '/admin/subcategories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::indexSubcategories
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
indexSubcategories.url = (options?: RouteQueryOptions) => {
    return indexSubcategories.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::indexSubcategories
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
indexSubcategories.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: indexSubcategories.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::indexSubcategories
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
indexSubcategories.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: indexSubcategories.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::indexSubcategories
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
    const indexSubcategoriesForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: indexSubcategories.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::indexSubcategories
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
        indexSubcategoriesForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexSubcategories.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::indexSubcategories
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
        indexSubcategoriesForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: indexSubcategories.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    indexSubcategories.form = indexSubcategoriesForm
/**
* @see \App\Http\Controllers\CategoryController::createSubcategory
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
export const createSubcategory = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSubcategory.url(options),
    method: 'get',
})

createSubcategory.definition = {
    methods: ["get","head"],
    url: '/admin/subcategories/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::createSubcategory
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
createSubcategory.url = (options?: RouteQueryOptions) => {
    return createSubcategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::createSubcategory
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
createSubcategory.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: createSubcategory.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::createSubcategory
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
createSubcategory.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: createSubcategory.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::createSubcategory
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
    const createSubcategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: createSubcategory.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::createSubcategory
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
        createSubcategoryForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createSubcategory.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::createSubcategory
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
        createSubcategoryForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: createSubcategory.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    createSubcategory.form = createSubcategoryForm
/**
* @see \App\Http\Controllers\CategoryController::storeSubcategory
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
export const storeSubcategory = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSubcategory.url(options),
    method: 'post',
})

storeSubcategory.definition = {
    methods: ["post"],
    url: '/admin/subcategories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CategoryController::storeSubcategory
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
storeSubcategory.url = (options?: RouteQueryOptions) => {
    return storeSubcategory.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::storeSubcategory
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
storeSubcategory.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: storeSubcategory.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CategoryController::storeSubcategory
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
    const storeSubcategoryForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: storeSubcategory.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::storeSubcategory
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
        storeSubcategoryForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: storeSubcategory.url(options),
            method: 'post',
        })
    
    storeSubcategory.form = storeSubcategoryForm
/**
* @see \App\Http\Controllers\CategoryController::editSubcategory
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
export const editSubcategory = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editSubcategory.url(args, options),
    method: 'get',
})

editSubcategory.definition = {
    methods: ["get","head"],
    url: '/admin/subcategories/{subcategory}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::editSubcategory
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
editSubcategory.url = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subcategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subcategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subcategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subcategory: typeof args.subcategory === 'object'
                ? args.subcategory.id
                : args.subcategory,
                }

    return editSubcategory.definition.url
            .replace('{subcategory}', parsedArgs.subcategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::editSubcategory
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
editSubcategory.get = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: editSubcategory.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::editSubcategory
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
editSubcategory.head = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: editSubcategory.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::editSubcategory
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
    const editSubcategoryForm = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: editSubcategory.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::editSubcategory
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
        editSubcategoryForm.get = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editSubcategory.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::editSubcategory
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
        editSubcategoryForm.head = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: editSubcategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    editSubcategory.form = editSubcategoryForm
/**
* @see \App\Http\Controllers\CategoryController::updateSubcategory
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
export const updateSubcategory = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSubcategory.url(args, options),
    method: 'put',
})

updateSubcategory.definition = {
    methods: ["put"],
    url: '/admin/subcategories/{subcategory}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CategoryController::updateSubcategory
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
updateSubcategory.url = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subcategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subcategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subcategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subcategory: typeof args.subcategory === 'object'
                ? args.subcategory.id
                : args.subcategory,
                }

    return updateSubcategory.definition.url
            .replace('{subcategory}', parsedArgs.subcategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::updateSubcategory
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
updateSubcategory.put = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: updateSubcategory.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CategoryController::updateSubcategory
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
    const updateSubcategoryForm = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateSubcategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::updateSubcategory
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
        updateSubcategoryForm.put = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateSubcategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    updateSubcategory.form = updateSubcategoryForm
/**
* @see \App\Http\Controllers\CategoryController::destroySubcategory
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
export const destroySubcategory = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySubcategory.url(args, options),
    method: 'delete',
})

destroySubcategory.definition = {
    methods: ["delete"],
    url: '/admin/subcategories/{subcategory}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CategoryController::destroySubcategory
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
destroySubcategory.url = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subcategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subcategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subcategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subcategory: typeof args.subcategory === 'object'
                ? args.subcategory.id
                : args.subcategory,
                }

    return destroySubcategory.definition.url
            .replace('{subcategory}', parsedArgs.subcategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::destroySubcategory
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
destroySubcategory.delete = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroySubcategory.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CategoryController::destroySubcategory
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
    const destroySubcategoryForm = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroySubcategory.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::destroySubcategory
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
        destroySubcategoryForm.delete = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroySubcategory.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroySubcategory.form = destroySubcategoryForm
const CategoryController = { indexCategories, createCategory, storeCategory, editCategory, updateCategory, destroyCategory, manageTechnicianCategories, assignTechniciansToCategory, indexSubcategories, createSubcategory, storeSubcategory, editSubcategory, updateSubcategory, destroySubcategory }

export default CategoryController