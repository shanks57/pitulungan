import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::performanceReport
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
export const performanceReport = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: performanceReport.url(options),
    method: 'get',
})

performanceReport.definition = {
    methods: ["get","head"],
    url: '/admin/reports/performance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::performanceReport
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
performanceReport.url = (options?: RouteQueryOptions) => {
    return performanceReport.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::performanceReport
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
performanceReport.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: performanceReport.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::performanceReport
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
performanceReport.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: performanceReport.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::performanceReport
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
    const performanceReportForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: performanceReport.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::performanceReport
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
        performanceReportForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: performanceReport.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::performanceReport
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
        performanceReportForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: performanceReport.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    performanceReport.form = performanceReportForm
const ReportController = { performanceReport }

export default ReportController