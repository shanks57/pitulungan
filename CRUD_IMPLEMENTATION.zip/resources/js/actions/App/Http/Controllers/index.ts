import DashboardController from './DashboardController'
import TicketController from './TicketController'
import TicketCommentController from './TicketCommentController'
import PushSubscriptionController from './PushSubscriptionController'
import MobileDeviceController from './MobileDeviceController'
import UserController from './UserController'
import ReportController from './ReportController'
import CategoryController from './CategoryController'
import Settings from './Settings'
const Controllers = {
    DashboardController: Object.assign(DashboardController, DashboardController),
TicketController: Object.assign(TicketController, TicketController),
TicketCommentController: Object.assign(TicketCommentController, TicketCommentController),
PushSubscriptionController: Object.assign(PushSubscriptionController, PushSubscriptionController),
MobileDeviceController: Object.assign(MobileDeviceController, MobileDeviceController),
UserController: Object.assign(UserController, UserController),
ReportController: Object.assign(ReportController, ReportController),
CategoryController: Object.assign(CategoryController, CategoryController),
Settings: Object.assign(Settings, Settings),
}

export default Controllers