import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:99
 * @route '/tickets/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/tickets/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:99
 * @route '/tickets/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:99
 * @route '/tickets/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:99
 * @route '/tickets/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:99
 * @route '/tickets/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:99
 * @route '/tickets/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::create
 * @see app/Http/Controllers/TicketController.php:99
 * @route '/tickets/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:110
 * @route '/tickets'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/tickets',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:110
 * @route '/tickets'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:110
 * @route '/tickets'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:110
 * @route '/tickets'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::store
 * @see app/Http/Controllers/TicketController.php:110
 * @route '/tickets'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\TicketController::userTickets
 * @see app/Http/Controllers/TicketController.php:358
 * @route '/user/tickets'
 */
export const userTickets = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userTickets.url(options),
    method: 'get',
})

userTickets.definition = {
    methods: ["get","head"],
    url: '/user/tickets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::userTickets
 * @see app/Http/Controllers/TicketController.php:358
 * @route '/user/tickets'
 */
userTickets.url = (options?: RouteQueryOptions) => {
    return userTickets.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::userTickets
 * @see app/Http/Controllers/TicketController.php:358
 * @route '/user/tickets'
 */
userTickets.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: userTickets.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::userTickets
 * @see app/Http/Controllers/TicketController.php:358
 * @route '/user/tickets'
 */
userTickets.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: userTickets.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::userTickets
 * @see app/Http/Controllers/TicketController.php:358
 * @route '/user/tickets'
 */
    const userTicketsForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: userTickets.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::userTickets
 * @see app/Http/Controllers/TicketController.php:358
 * @route '/user/tickets'
 */
        userTicketsForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userTickets.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::userTickets
 * @see app/Http/Controllers/TicketController.php:358
 * @route '/user/tickets'
 */
        userTicketsForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: userTickets.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    userTickets.form = userTicketsForm
/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/user/tickets/{ticket}'
 */
const showf4b1a96730d357610fdd8b2f2198a80a = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showf4b1a96730d357610fdd8b2f2198a80a.url(args, options),
    method: 'get',
})

showf4b1a96730d357610fdd8b2f2198a80a.definition = {
    methods: ["get","head"],
    url: '/user/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/user/tickets/{ticket}'
 */
showf4b1a96730d357610fdd8b2f2198a80a.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return showf4b1a96730d357610fdd8b2f2198a80a.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/user/tickets/{ticket}'
 */
showf4b1a96730d357610fdd8b2f2198a80a.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: showf4b1a96730d357610fdd8b2f2198a80a.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/user/tickets/{ticket}'
 */
showf4b1a96730d357610fdd8b2f2198a80a.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: showf4b1a96730d357610fdd8b2f2198a80a.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/user/tickets/{ticket}'
 */
    const showf4b1a96730d357610fdd8b2f2198a80aForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: showf4b1a96730d357610fdd8b2f2198a80a.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/user/tickets/{ticket}'
 */
        showf4b1a96730d357610fdd8b2f2198a80aForm.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showf4b1a96730d357610fdd8b2f2198a80a.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/user/tickets/{ticket}'
 */
        showf4b1a96730d357610fdd8b2f2198a80aForm.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: showf4b1a96730d357610fdd8b2f2198a80a.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    showf4b1a96730d357610fdd8b2f2198a80a.form = showf4b1a96730d357610fdd8b2f2198a80aForm
    /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/technician/tickets/{ticket}'
 */
const show4f12f4154db833822f35d1c22a73b1c8 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show4f12f4154db833822f35d1c22a73b1c8.url(args, options),
    method: 'get',
})

show4f12f4154db833822f35d1c22a73b1c8.definition = {
    methods: ["get","head"],
    url: '/technician/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/technician/tickets/{ticket}'
 */
show4f12f4154db833822f35d1c22a73b1c8.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return show4f12f4154db833822f35d1c22a73b1c8.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/technician/tickets/{ticket}'
 */
show4f12f4154db833822f35d1c22a73b1c8.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show4f12f4154db833822f35d1c22a73b1c8.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/technician/tickets/{ticket}'
 */
show4f12f4154db833822f35d1c22a73b1c8.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show4f12f4154db833822f35d1c22a73b1c8.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/technician/tickets/{ticket}'
 */
    const show4f12f4154db833822f35d1c22a73b1c8Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show4f12f4154db833822f35d1c22a73b1c8.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/technician/tickets/{ticket}'
 */
        show4f12f4154db833822f35d1c22a73b1c8Form.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show4f12f4154db833822f35d1c22a73b1c8.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/technician/tickets/{ticket}'
 */
        show4f12f4154db833822f35d1c22a73b1c8Form.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show4f12f4154db833822f35d1c22a73b1c8.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show4f12f4154db833822f35d1c22a73b1c8.form = show4f12f4154db833822f35d1c22a73b1c8Form
    /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/admin/tickets/{ticket}'
 */
const show89d421f5946fd92d266d02c1d3fc3b35 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
    method: 'get',
})

show89d421f5946fd92d266d02c1d3fc3b35.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/admin/tickets/{ticket}'
 */
show89d421f5946fd92d266d02c1d3fc3b35.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return show89d421f5946fd92d266d02c1d3fc3b35.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/admin/tickets/{ticket}'
 */
show89d421f5946fd92d266d02c1d3fc3b35.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: show89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/admin/tickets/{ticket}'
 */
show89d421f5946fd92d266d02c1d3fc3b35.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: show89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/admin/tickets/{ticket}'
 */
    const show89d421f5946fd92d266d02c1d3fc3b35Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: show89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/admin/tickets/{ticket}'
 */
        show89d421f5946fd92d266d02c1d3fc3b35Form.get = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::show
 * @see app/Http/Controllers/TicketController.php:418
 * @route '/admin/tickets/{ticket}'
 */
        show89d421f5946fd92d266d02c1d3fc3b35Form.head = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: show89d421f5946fd92d266d02c1d3fc3b35.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    show89d421f5946fd92d266d02c1d3fc3b35.form = show89d421f5946fd92d266d02c1d3fc3b35Form

export const show = {
    '/user/tickets/{ticket}': showf4b1a96730d357610fdd8b2f2198a80a,
    '/technician/tickets/{ticket}': show4f12f4154db833822f35d1c22a73b1c8,
    '/admin/tickets/{ticket}': show89d421f5946fd92d266d02c1d3fc3b35,
}

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/technician/tickets/{ticket}'
 */
const update4f12f4154db833822f35d1c22a73b1c8 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update4f12f4154db833822f35d1c22a73b1c8.url(args, options),
    method: 'put',
})

update4f12f4154db833822f35d1c22a73b1c8.definition = {
    methods: ["put"],
    url: '/technician/tickets/{ticket}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/technician/tickets/{ticket}'
 */
update4f12f4154db833822f35d1c22a73b1c8.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return update4f12f4154db833822f35d1c22a73b1c8.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/technician/tickets/{ticket}'
 */
update4f12f4154db833822f35d1c22a73b1c8.put = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update4f12f4154db833822f35d1c22a73b1c8.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/technician/tickets/{ticket}'
 */
    const update4f12f4154db833822f35d1c22a73b1c8Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update4f12f4154db833822f35d1c22a73b1c8.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/technician/tickets/{ticket}'
 */
        update4f12f4154db833822f35d1c22a73b1c8Form.put = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update4f12f4154db833822f35d1c22a73b1c8.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update4f12f4154db833822f35d1c22a73b1c8.form = update4f12f4154db833822f35d1c22a73b1c8Form
    /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/admin/tickets/{ticket}'
 */
const update89d421f5946fd92d266d02c1d3fc3b35 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
    method: 'put',
})

update89d421f5946fd92d266d02c1d3fc3b35.definition = {
    methods: ["put","patch"],
    url: '/admin/tickets/{ticket}',
} satisfies RouteDefinition<["put","patch"]>

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/admin/tickets/{ticket}'
 */
update89d421f5946fd92d266d02c1d3fc3b35.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return update89d421f5946fd92d266d02c1d3fc3b35.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/admin/tickets/{ticket}'
 */
update89d421f5946fd92d266d02c1d3fc3b35.put = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
    method: 'put',
})
/**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/admin/tickets/{ticket}'
 */
update89d421f5946fd92d266d02c1d3fc3b35.patch = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'patch'> => ({
    url: update89d421f5946fd92d266d02c1d3fc3b35.url(args, options),
    method: 'patch',
})

    /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/admin/tickets/{ticket}'
 */
    const update89d421f5946fd92d266d02c1d3fc3b35Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update89d421f5946fd92d266d02c1d3fc3b35.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/admin/tickets/{ticket}'
 */
        update89d421f5946fd92d266d02c1d3fc3b35Form.put = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update89d421f5946fd92d266d02c1d3fc3b35.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
            /**
* @see \App\Http\Controllers\TicketController::update
 * @see app/Http/Controllers/TicketController.php:237
 * @route '/admin/tickets/{ticket}'
 */
        update89d421f5946fd92d266d02c1d3fc3b35Form.patch = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update89d421f5946fd92d266d02c1d3fc3b35.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PATCH',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update89d421f5946fd92d266d02c1d3fc3b35.form = update89d421f5946fd92d266d02c1d3fc3b35Form

export const update = {
    '/technician/tickets/{ticket}': update4f12f4154db833822f35d1c22a73b1c8,
    '/admin/tickets/{ticket}': update89d421f5946fd92d266d02c1d3fc3b35,
}

/**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/technician/tickets/{ticket}/status'
 */
const updateStatus83df61a9a540f0f6c4f852dec16f81c7 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus83df61a9a540f0f6c4f852dec16f81c7.url(args, options),
    method: 'post',
})

updateStatus83df61a9a540f0f6c4f852dec16f81c7.definition = {
    methods: ["post"],
    url: '/technician/tickets/{ticket}/status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/technician/tickets/{ticket}/status'
 */
updateStatus83df61a9a540f0f6c4f852dec16f81c7.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return updateStatus83df61a9a540f0f6c4f852dec16f81c7.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/technician/tickets/{ticket}/status'
 */
updateStatus83df61a9a540f0f6c4f852dec16f81c7.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatus83df61a9a540f0f6c4f852dec16f81c7.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/technician/tickets/{ticket}/status'
 */
    const updateStatus83df61a9a540f0f6c4f852dec16f81c7Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatus83df61a9a540f0f6c4f852dec16f81c7.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/technician/tickets/{ticket}/status'
 */
        updateStatus83df61a9a540f0f6c4f852dec16f81c7Form.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatus83df61a9a540f0f6c4f852dec16f81c7.url(args, options),
            method: 'post',
        })
    
    updateStatus83df61a9a540f0f6c4f852dec16f81c7.form = updateStatus83df61a9a540f0f6c4f852dec16f81c7Form
    /**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/admin/tickets/{ticket}/status'
 */
const updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5 = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.url(args, options),
    method: 'post',
})

updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.definition = {
    methods: ["post"],
    url: '/admin/tickets/{ticket}/status',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/admin/tickets/{ticket}/status'
 */
updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/admin/tickets/{ticket}/status'
 */
updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/admin/tickets/{ticket}/status'
 */
    const updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5Form = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::updateStatus
 * @see app/Http/Controllers/TicketController.php:285
 * @route '/admin/tickets/{ticket}/status'
 */
        updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5Form.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.url(args, options),
            method: 'post',
        })
    
    updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5.form = updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5Form

export const updateStatus = {
    '/technician/tickets/{ticket}/status': updateStatus83df61a9a540f0f6c4f852dec16f81c7,
    '/admin/tickets/{ticket}/status': updateStatusf8ba5fd7042a5fc40608b1a3eb6a0fd5,
}

/**
* @see \App\Http\Controllers\TicketController::addProgress
 * @see app/Http/Controllers/TicketController.php:328
 * @route '/technician/tickets/{ticket}/progress'
 */
export const addProgress = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addProgress.url(args, options),
    method: 'post',
})

addProgress.definition = {
    methods: ["post"],
    url: '/technician/tickets/{ticket}/progress',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::addProgress
 * @see app/Http/Controllers/TicketController.php:328
 * @route '/technician/tickets/{ticket}/progress'
 */
addProgress.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return addProgress.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::addProgress
 * @see app/Http/Controllers/TicketController.php:328
 * @route '/technician/tickets/{ticket}/progress'
 */
addProgress.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: addProgress.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::addProgress
 * @see app/Http/Controllers/TicketController.php:328
 * @route '/technician/tickets/{ticket}/progress'
 */
    const addProgressForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: addProgress.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::addProgress
 * @see app/Http/Controllers/TicketController.php:328
 * @route '/technician/tickets/{ticket}/progress'
 */
        addProgressForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: addProgress.url(args, options),
            method: 'post',
        })
    
    addProgress.form = addProgressForm
/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:22
 * @route '/admin/tickets'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/tickets',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:22
 * @route '/admin/tickets'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:22
 * @route '/admin/tickets'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:22
 * @route '/admin/tickets'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:22
 * @route '/admin/tickets'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:22
 * @route '/admin/tickets'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::index
 * @see app/Http/Controllers/TicketController.php:22
 * @route '/admin/tickets'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}/edit'
 */
export const edit = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/tickets/{ticket}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return edit.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}/edit'
 */
edit.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}/edit'
 */
    const editForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}/edit'
 */
        editForm.get = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\TicketController::edit
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}/edit'
 */
        editForm.head = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}'
 */
export const destroy = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/tickets/{ticket}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}'
 */
destroy.url = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: args.ticket,
                }

    return destroy.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}'
 */
destroy.delete = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}'
 */
    const destroyForm = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::destroy
 * @see app/Http/Controllers/TicketController.php:0
 * @route '/admin/tickets/{ticket}'
 */
        destroyForm.delete = (args: { ticket: string | number } | [ticket: string | number ] | string | number, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
/**
* @see \App\Http\Controllers\TicketController::assign
 * @see app/Http/Controllers/TicketController.php:211
 * @route '/admin/tickets/{ticket}/assign'
 */
export const assign = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(args, options),
    method: 'post',
})

assign.definition = {
    methods: ["post"],
    url: '/admin/tickets/{ticket}/assign',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\TicketController::assign
 * @see app/Http/Controllers/TicketController.php:211
 * @route '/admin/tickets/{ticket}/assign'
 */
assign.url = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { ticket: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { ticket: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    ticket: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        ticket: typeof args.ticket === 'object'
                ? args.ticket.id
                : args.ticket,
                }

    return assign.definition.url
            .replace('{ticket}', parsedArgs.ticket.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\TicketController::assign
 * @see app/Http/Controllers/TicketController.php:211
 * @route '/admin/tickets/{ticket}/assign'
 */
assign.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: assign.url(args, options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\TicketController::assign
 * @see app/Http/Controllers/TicketController.php:211
 * @route '/admin/tickets/{ticket}/assign'
 */
    const assignForm = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: assign.url(args, options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\TicketController::assign
 * @see app/Http/Controllers/TicketController.php:211
 * @route '/admin/tickets/{ticket}/assign'
 */
        assignForm.post = (args: { ticket: number | { id: number } } | [ticket: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: assign.url(args, options),
            method: 'post',
        })
    
    assign.form = assignForm
const TicketController = { create, store, userTickets, show, update, updateStatus, addProgress, index, edit, destroy, assign }

export default TicketController