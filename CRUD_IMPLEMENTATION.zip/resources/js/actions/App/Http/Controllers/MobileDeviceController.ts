import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\MobileDeviceController::store
 * @see app/Http/Controllers/MobileDeviceController.php:12
 * @route '/mobile/devices'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/mobile/devices',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MobileDeviceController::store
 * @see app/Http/Controllers/MobileDeviceController.php:12
 * @route '/mobile/devices'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MobileDeviceController::store
 * @see app/Http/Controllers/MobileDeviceController.php:12
 * @route '/mobile/devices'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MobileDeviceController::store
 * @see app/Http/Controllers/MobileDeviceController.php:12
 * @route '/mobile/devices'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MobileDeviceController::store
 * @see app/Http/Controllers/MobileDeviceController.php:12
 * @route '/mobile/devices'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\MobileDeviceController::destroy
 * @see app/Http/Controllers/MobileDeviceController.php:38
 * @route '/mobile/devices/unregister'
 */
export const destroy = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

destroy.definition = {
    methods: ["post"],
    url: '/mobile/devices/unregister',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\MobileDeviceController::destroy
 * @see app/Http/Controllers/MobileDeviceController.php:38
 * @route '/mobile/devices/unregister'
 */
destroy.url = (options?: RouteQueryOptions) => {
    return destroy.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\MobileDeviceController::destroy
 * @see app/Http/Controllers/MobileDeviceController.php:38
 * @route '/mobile/devices/unregister'
 */
destroy.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: destroy.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\MobileDeviceController::destroy
 * @see app/Http/Controllers/MobileDeviceController.php:38
 * @route '/mobile/devices/unregister'
 */
    const destroyForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\MobileDeviceController::destroy
 * @see app/Http/Controllers/MobileDeviceController.php:38
 * @route '/mobile/devices/unregister'
 */
        destroyForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(options),
            method: 'post',
        })
    
    destroy.form = destroyForm
const MobileDeviceController = { store, destroy }

export default MobileDeviceController