import users from './users'
import tickets from './tickets'
import admin from './admin'
import categories from './categories'
import subcategories from './subcategories'
const admin = {
    users: Object.assign(users, users),
tickets: Object.assign(tickets, tickets),
admin: Object.assign(admin, admin),
categories: Object.assign(categories, categories),
subcategories: Object.assign(subcategories, subcategories),
}

export default admin