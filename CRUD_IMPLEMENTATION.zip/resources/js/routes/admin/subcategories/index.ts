import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition, applyUrlDefaults } from './../../../wayfinder'
/**
* @see \App\Http\Controllers\CategoryController::index
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
export const index = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})

index.definition = {
    methods: ["get","head"],
    url: '/admin/subcategories',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::index
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
index.url = (options?: RouteQueryOptions) => {
    return index.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::index
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
index.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: index.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::index
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
index.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: index.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::index
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
    const indexForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: index.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::index
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
        indexForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::index
 * @see app/Http/Controllers/CategoryController.php:75
 * @route '/admin/subcategories'
 */
        indexForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: index.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    index.form = indexForm
/**
* @see \App\Http\Controllers\CategoryController::create
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
export const create = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})

create.definition = {
    methods: ["get","head"],
    url: '/admin/subcategories/create',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::create
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
create.url = (options?: RouteQueryOptions) => {
    return create.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::create
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
create.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: create.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::create
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
create.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: create.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::create
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
    const createForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: create.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::create
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
        createForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::create
 * @see app/Http/Controllers/CategoryController.php:85
 * @route '/admin/subcategories/create'
 */
        createForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: create.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    create.form = createForm
/**
* @see \App\Http\Controllers\CategoryController::store
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
export const store = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

store.definition = {
    methods: ["post"],
    url: '/admin/subcategories',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\CategoryController::store
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
store.url = (options?: RouteQueryOptions) => {
    return store.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::store
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
store.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: store.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\CategoryController::store
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
    const storeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: store.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::store
 * @see app/Http/Controllers/CategoryController.php:94
 * @route '/admin/subcategories'
 */
        storeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: store.url(options),
            method: 'post',
        })
    
    store.form = storeForm
/**
* @see \App\Http\Controllers\CategoryController::edit
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
export const edit = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})

edit.definition = {
    methods: ["get","head"],
    url: '/admin/subcategories/{subcategory}/edit',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\CategoryController::edit
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
edit.url = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subcategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subcategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subcategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subcategory: typeof args.subcategory === 'object'
                ? args.subcategory.id
                : args.subcategory,
                }

    return edit.definition.url
            .replace('{subcategory}', parsedArgs.subcategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::edit
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
edit.get = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: edit.url(args, options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\CategoryController::edit
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
edit.head = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: edit.url(args, options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\CategoryController::edit
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
    const editForm = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: edit.url(args, options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\CategoryController::edit
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
        editForm.get = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\CategoryController::edit
 * @see app/Http/Controllers/CategoryController.php:111
 * @route '/admin/subcategories/{subcategory}/edit'
 */
        editForm.head = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: edit.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    edit.form = editForm
/**
* @see \App\Http\Controllers\CategoryController::update
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
export const update = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

update.definition = {
    methods: ["put"],
    url: '/admin/subcategories/{subcategory}',
} satisfies RouteDefinition<["put"]>

/**
* @see \App\Http\Controllers\CategoryController::update
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
update.url = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subcategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subcategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subcategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subcategory: typeof args.subcategory === 'object'
                ? args.subcategory.id
                : args.subcategory,
                }

    return update.definition.url
            .replace('{subcategory}', parsedArgs.subcategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::update
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
update.put = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'put'> => ({
    url: update.url(args, options),
    method: 'put',
})

    /**
* @see \App\Http\Controllers\CategoryController::update
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
    const updateForm = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: update.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'PUT',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::update
 * @see app/Http/Controllers/CategoryController.php:121
 * @route '/admin/subcategories/{subcategory}'
 */
        updateForm.put = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: update.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'PUT',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    update.form = updateForm
/**
* @see \App\Http\Controllers\CategoryController::destroy
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
export const destroy = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

destroy.definition = {
    methods: ["delete"],
    url: '/admin/subcategories/{subcategory}',
} satisfies RouteDefinition<["delete"]>

/**
* @see \App\Http\Controllers\CategoryController::destroy
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
destroy.url = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions) => {
    if (typeof args === 'string' || typeof args === 'number') {
        args = { subcategory: args }
    }

            if (typeof args === 'object' && !Array.isArray(args) && 'id' in args) {
            args = { subcategory: args.id }
        }
    
    if (Array.isArray(args)) {
        args = {
                    subcategory: args[0],
                }
    }

    args = applyUrlDefaults(args)

    const parsedArgs = {
                        subcategory: typeof args.subcategory === 'object'
                ? args.subcategory.id
                : args.subcategory,
                }

    return destroy.definition.url
            .replace('{subcategory}', parsedArgs.subcategory.toString())
            .replace(/\/+$/, '') + queryParams(options)
}

/**
* @see \App\Http\Controllers\CategoryController::destroy
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
destroy.delete = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteDefinition<'delete'> => ({
    url: destroy.url(args, options),
    method: 'delete',
})

    /**
* @see \App\Http\Controllers\CategoryController::destroy
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
    const destroyForm = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: destroy.url(args, {
                    [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                        _method: 'DELETE',
                        ...(options?.query ?? options?.mergeQuery ?? {}),
                    }
                }),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\CategoryController::destroy
 * @see app/Http/Controllers/CategoryController.php:138
 * @route '/admin/subcategories/{subcategory}'
 */
        destroyForm.delete = (args: { subcategory: number | { id: number } } | [subcategory: number | { id: number } ] | number | { id: number }, options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: destroy.url(args, {
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'DELETE',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'post',
        })
    
    destroy.form = destroyForm
const subcategories = {
    index: Object.assign(index, index),
create: Object.assign(create, create),
store: Object.assign(store, store),
edit: Object.assign(edit, edit),
update: Object.assign(update, update),
destroy: Object.assign(destroy, destroy),
}

export default subcategories