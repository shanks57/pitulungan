import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../../../wayfinder'
/**
* @see \App\Http\Controllers\ReportController::performance
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
export const performance = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: performance.url(options),
    method: 'get',
})

performance.definition = {
    methods: ["get","head"],
    url: '/admin/reports/performance',
} satisfies RouteDefinition<["get","head"]>

/**
* @see \App\Http\Controllers\ReportController::performance
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
performance.url = (options?: RouteQueryOptions) => {
    return performance.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\ReportController::performance
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
performance.get = (options?: RouteQueryOptions): RouteDefinition<'get'> => ({
    url: performance.url(options),
    method: 'get',
})
/**
* @see \App\Http\Controllers\ReportController::performance
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
performance.head = (options?: RouteQueryOptions): RouteDefinition<'head'> => ({
    url: performance.url(options),
    method: 'head',
})

    /**
* @see \App\Http\Controllers\ReportController::performance
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
    const performanceForm = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
        action: performance.url(options),
        method: 'get',
    })

            /**
* @see \App\Http\Controllers\ReportController::performance
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
        performanceForm.get = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: performance.url(options),
            method: 'get',
        })
            /**
* @see \App\Http\Controllers\ReportController::performance
 * @see app/Http/Controllers/ReportController.php:18
 * @route '/admin/reports/performance'
 */
        performanceForm.head = (options?: RouteQueryOptions): RouteFormDefinition<'get'> => ({
            action: performance.url({
                        [options?.mergeQuery ? 'mergeQuery' : 'query']: {
                            _method: 'HEAD',
                            ...(options?.query ?? options?.mergeQuery ?? {}),
                        }
                    }),
            method: 'get',
        })
    
    performance.form = performanceForm
const reports = {
    performance: Object.assign(performance, performance),
}

export default reports