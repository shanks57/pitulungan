import reports from './reports'
const admin = {
    reports: Object.assign(reports, reports),
}

export default admin