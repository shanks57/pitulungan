import devices from './devices'
const mobile = {
    devices: Object.assign(devices, devices),
}

export default mobile