import { queryParams, type RouteQueryOptions, type RouteDefinition, type RouteFormDefinition } from './../../wayfinder'
/**
* @see \App\Http\Controllers\PushSubscriptionController::subscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:10
 * @route '/web-push/subscribe'
 */
export const subscribe = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe.url(options),
    method: 'post',
})

subscribe.definition = {
    methods: ["post"],
    url: '/web-push/subscribe',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PushSubscriptionController::subscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:10
 * @route '/web-push/subscribe'
 */
subscribe.url = (options?: RouteQueryOptions) => {
    return subscribe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PushSubscriptionController::subscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:10
 * @route '/web-push/subscribe'
 */
subscribe.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: subscribe.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PushSubscriptionController::subscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:10
 * @route '/web-push/subscribe'
 */
    const subscribeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: subscribe.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PushSubscriptionController::subscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:10
 * @route '/web-push/subscribe'
 */
        subscribeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: subscribe.url(options),
            method: 'post',
        })
    
    subscribe.form = subscribeForm
/**
* @see \App\Http\Controllers\PushSubscriptionController::unsubscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:37
 * @route '/web-push/unsubscribe'
 */
export const unsubscribe = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(options),
    method: 'post',
})

unsubscribe.definition = {
    methods: ["post"],
    url: '/web-push/unsubscribe',
} satisfies RouteDefinition<["post"]>

/**
* @see \App\Http\Controllers\PushSubscriptionController::unsubscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:37
 * @route '/web-push/unsubscribe'
 */
unsubscribe.url = (options?: RouteQueryOptions) => {
    return unsubscribe.definition.url + queryParams(options)
}

/**
* @see \App\Http\Controllers\PushSubscriptionController::unsubscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:37
 * @route '/web-push/unsubscribe'
 */
unsubscribe.post = (options?: RouteQueryOptions): RouteDefinition<'post'> => ({
    url: unsubscribe.url(options),
    method: 'post',
})

    /**
* @see \App\Http\Controllers\PushSubscriptionController::unsubscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:37
 * @route '/web-push/unsubscribe'
 */
    const unsubscribeForm = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
        action: unsubscribe.url(options),
        method: 'post',
    })

            /**
* @see \App\Http\Controllers\PushSubscriptionController::unsubscribe
 * @see app/Http/Controllers/PushSubscriptionController.php:37
 * @route '/web-push/unsubscribe'
 */
        unsubscribeForm.post = (options?: RouteQueryOptions): RouteFormDefinition<'post'> => ({
            action: unsubscribe.url(options),
            method: 'post',
        })
    
    unsubscribe.form = unsubscribeForm
const webpush = {
    subscribe: Object.assign(subscribe, subscribe),
unsubscribe: Object.assign(unsubscribe, unsubscribe),
}

export default webpush