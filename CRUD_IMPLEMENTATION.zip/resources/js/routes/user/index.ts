import tickets from './tickets'
const user = {
    tickets: Object.assign(tickets, tickets),
}

export default user