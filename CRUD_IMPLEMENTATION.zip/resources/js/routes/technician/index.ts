import tickets from './tickets'
const technician = {
    tickets: Object.assign(tickets, tickets),
}

export default technician