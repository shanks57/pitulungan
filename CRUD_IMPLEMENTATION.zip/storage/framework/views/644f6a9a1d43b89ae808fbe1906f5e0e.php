<?php
/** @var \Laravel\Boost\Install\GuidelineAssist $assist */
?>
## Inertia + React Forms

<?php if($assist->inertia()->hasFormComponent()): ?>
___BOOST_SNIPPET_0___
<?php endif; ?>

<?php if($assist->inertia()->hasFormComponent() === false): ?>

___BOOST_SNIPPET_1___
<?php endif; ?>
<?php /**PATH D:\Dev\External\ticket-app\storage\framework\views/84d54824125473110825ed8d8c18e3d3.blade.php ENDPATH**/ ?>