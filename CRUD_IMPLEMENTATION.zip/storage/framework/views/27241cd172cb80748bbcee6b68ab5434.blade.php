## Inertia + React

- Use ___SINGLE_BACKTICK___router.visit()___SINGLE_BACKTICK___ or ___SINGLE_BACKTICK___<Link>___SINGLE_BACKTICK___ for navigation instead of traditional links.

___BOOST_SNIPPET_0___
